package com.rk;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootJwtSecurityApplicationTests {

	@Test
	void contextLoads() {
	}

}
