package com.rk.service.impl;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.rk.model.User;
import com.rk.rpo.UserRepoitory;
import com.rk.service.IUserService;

@Service
public class UserServiceImpl implements IUserService, UserDetailsService {
	@Autowired
	private UserRepoitory repo;
	@Autowired
	private BCryptPasswordEncoder encoder1;

	@Override
	public Integer saveUser(User user) {
		String pwd = user.getPwd();
		pwd = encoder1.encode(pwd);
		user.setPwd(pwd);
		return repo.save(user).getId();
	}

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		// Model class based on User Name
		User user = repo.findByUsername(username);
		
		Set<GrantedAuthority> authorities = new HashSet<GrantedAuthority>();
		org.springframework.security.core.userdetails.User urs = new org.springframework.security.core.userdetails.User(
				user.getUsername(), user.getPwd(), authorities);
		return urs;
	}

}
