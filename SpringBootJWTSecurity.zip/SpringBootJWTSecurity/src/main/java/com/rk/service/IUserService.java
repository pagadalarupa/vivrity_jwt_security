package com.rk.service;

import com.rk.model.User;

public interface IUserService {
	Integer saveUser(User user);

}
