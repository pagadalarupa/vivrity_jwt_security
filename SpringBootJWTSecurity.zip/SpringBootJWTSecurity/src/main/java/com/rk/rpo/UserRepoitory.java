package com.rk.rpo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.rk.model.User;

public interface UserRepoitory extends JpaRepository<User, Integer> {
	User findByUsername(String username);

}
